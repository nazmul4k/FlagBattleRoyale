FLAG BATTLE ROYALE - ANDROID STUDIO PROJECT
===========================================

এই ZIP-এ আপনার HTML গেমটি Android WebView অ্যাপে চালানোর জন্য project source দেওয়া হয়েছে।
এটি APK নয়; Android Studio দিয়ে Debug APK ও signed Release APK build করতে হবে।

যা লাগবে:
- Android Studio (সাম্প্রতিক stable version)
- Android SDK Platform 35
- JDK 17 (Android Studio-র bundled JDK ব্যবহার করা যায়)
- Internet connection (আপনার HTML-এ Tailwind CDN, Font Awesome ও Google Fonts আছে)

BUILD:
1. ZIP extract করুন।
2. Android Studio > Open > extracted FlagBattleRoyale folder নির্বাচন করুন।
3. Gradle sync শেষ হতে দিন; SDK 35 চাইলে install করুন।
4. Debug APK: Build > Build Bundle(s) / APK(s) > Build APK(s)
   ফাইল: app/build/outputs/apk/debug/app-debug.apk
5. Release APK: Build > Generate Signed Bundle / APK > APK নির্বাচন করুন।
   নতুন keystore তৈরি করে password নিরাপদে সংরক্ষণ করুন।
   Release build শেষ হলে signed APK পাবেন।

গুরুত্বপূর্ণ:
- Release APK শেয়ার করার জন্য signed APK ব্যবহার করুন।
- Keystore ও password হারাবেন না; ভবিষ্যৎ update-এ একই signing key দরকার হবে।
- গেমের HTML app/src/main/assets/index.html ফাইলে রাখা হয়েছে।
- HTML-এর বাইরের CDN/font resource লোড করতে internet permission রাখা হয়েছে।
- প্রথম build-এর পর বাস্তব Android ফোনে game controls, sound ও performance পরীক্ষা করুন।
